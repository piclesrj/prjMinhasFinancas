package com.prodrigues.minhasfinancas.Exception;

public class RegraDeNegocioException extends RuntimeException {
	
	public RegraDeNegocioException(String msg) {
		super(msg);
	}
}
