package com.prodrigues.minhasfinancas.model.enums;

public enum StatusLancamento {
	
	PENDENTE,CANCELADO,EFETIVADO

}
