package com.prodrigues.minhasfinancas.model.enums;

public enum TipoLancamento {

	RECEITA,DESPESA
}
