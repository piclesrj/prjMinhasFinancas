package com.prodrigues.minhasfinancas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinhasfinancasApplicationTests {

	@Test
	void contextLoads() {
	}

}
